
This font is for PERSONAL USE only.

Get the commercial license here:
https://www.myfonts.com/fonts/gravitype/astroz/


Check out other fonts by Gravitype:
https://www.myfonts.com/search/gravitype/